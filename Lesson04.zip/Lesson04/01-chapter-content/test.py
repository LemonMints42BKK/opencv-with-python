import constant
# Getting red color:
print("red: '{}'".format(constant.RED))
